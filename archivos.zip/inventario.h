#ifndef TP_3_INVENTARIO_H
#define TP_3_INVENTARIO_H

#include "material.h"
#include <string>

using namespace std;

class Inventario{
    private:
        int piedra,madera,metal,bombas,andycoins;
    public:
        /*
         * Constructor:
         * Pre: -.
         * Post: Me va a crear el objeto Materiales con total_materiales = 0.
         */
        Inventario();

        /*
         * Destructor:
         * Pre: -.
         * Post: Me va a descruir el objeto Materiales.
         */
        ~Inventario();
        /*
         * Pre: Recibe un objeto Material.
         * Post: Ingresa el objeto en un vector dinámico.
         */
        void agregar_material(string nombre, int cantidad);

        /*
         * Pre: -
         * Post: Me muestra lista por pantalla toso los objetos del tipo Material.
         */
        void mostrar();
        ;
};


#endif //TP_3_INVENTARIO_H
