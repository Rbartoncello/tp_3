#ifndef ARCHIVO_H
#define ARCHIVO_H
#include "diccionario.h"
#include "constantes.h"
#include <fstream>
#include <iostream>
#include "emojis.h"
#include "inventario.h"

class Archivo {
    private:
        Diccionario* diccionario;

    public:

        //Pre:Debe recibir el nombre del Archivo.
        //Post: crea la Lista.
        Archivo();

        //Pre:-
        //Post:devuelve el estado del la variable existeciaArchivo, tiene almacenada si el archivo se leyo correctamente.
        bool getArchivoValido();

        //Pre:
        //Post:Recorre el txt de forma polimorfica.
        int leer_archivos_materiales(Inventario* &inventario_jugador_1,Inventario* &inventario_jugador_2);

        //Pre:
        //Post:Recorre el txt de forma polimorfica.
        //int leer_archivos_edificios(Juego* &juego);

        //Pre:
        //Post:Recorre el txt de forma polimorfica.
        //  void leerArchivoMapa(string nombre);

        //Pre:
        //Post:Recorre el txt de forma polimorfica.
        int leer_archivo_ubicaciones();


        //Pre:
        //Post:retorna el nombre del archivo.
        string devolverNombre();

        ~Archivo() ;

    private:

        //Pre:Debe recibir el nombre del Archivo.
        //Post:valida si existe el Archivo.
        void validarArchivo();

};

#endif //ARCHIVO_H
