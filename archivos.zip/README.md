# tp_3
Los archivos tienen que estar dentro de la carpeta "archivos"