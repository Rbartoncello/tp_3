#include "archivo.h"

/*
 *
 *  Tenemos que discutir si la lectura de Mapa la hacemos en esta unica clase o en cada una
 *
 *
 *  de las clases
 *
 *
 */

Archivo::Archivo()
{
    Diccionario *diccionario = nullptr;
}
/*
int Archivo::leer_archivos_edificios(Juego* &juego)  {
    diccionario = new Diccionario;

    ifstream archivo(PATH_EDIFICIO);
    string nombre, piedra, madera, metal, max_cant_permitidos, nombre_aux;

    if (!archivo.is_open()){
        cout << "No se pudo abrir el archivo: " << PATH_EDIFICIO << endl;
        return ERROR;
    } else {
        while ( archivo >> nombre ){
            if (nombre == PLANTA){
                archivo >> nombre_aux;
                nombre += " " + nombre_aux;
            }

            string emoji = juego->buscar_tipo_emoji(nombre);
            archivo >> piedra;
            archivo >> madera;
            archivo >> metal;
            archivo >> max_cant_permitidos;

            diccionario->insertar(new Edificio (nombre, emoji, stoi(piedra), stoi(madera), stoi(metal), stoi(max_cant_permitidos)));
        }
        archivo.close();
    }

    diccionario->imprimir_in_orden();

    string nombre_edificio = "fabrica";
    cout << endl << "Piedra: " << diccionario->buscar(nombre_edificio).devoler_piedra() << " Madera: " << diccionario->buscar(nombre_edificio).devoler_madera() << " Metal: " << diccionario->buscar(nombre_edificio).devoler_metal() << endl;


    return 1;
}
 */
int Archivo::leer_archivos_materiales(Inventario *&inventario_jugador_1, Inventario *&inventario_jugador_2)
{

    ifstream archivo(PATH_MATERIALES);

    string nombre, cantidad_jugador_1, cantidad_jugador_2;

    if (!archivo.is_open())
    {
        cout << "No se pudo abrir el archivo: " << PATH_MATERIALES << endl;
        return ERROR;
    }
    else
    {
        while (archivo >> nombre)
        {
            archivo >> cantidad_jugador_1;
            archivo >> cantidad_jugador_2;
            inventario_jugador_1->agregar_material(nombre, stoi(cantidad_jugador_1));
            inventario_jugador_2->agregar_material(nombre, stoi(cantidad_jugador_2));
        }
    }
    archivo.close();

    return 0;
}

int Archivo::leer_archivo_ubicaciones(){

    /*fstream documento(PATH_UBICACIONES, ios::in);

    if (!documento.is_open())
    {
        cout << "No se pudo abrir el archivo: " << PATH_MATERIALES << endl;
        return ERROR;
    }

    string nombreEdificio, segundoNombre;
    string coordX, coordY;
    int cleanCoordX, cleanCoordY;

    while (documento >> nombreEdificio)
    {
        if (nombreEdificio == "planta")
        {
            documento >> segundoNombre;
            nombreEdificio = nombreEdificio + " " + segundoNombre;
        }

        documento >> coordX;
        documento >> coordY;

        cleanCoordX = arreglarCoordenadaX(coordX);
        cleanCoordY = arreglarCoordenadaY(coordY);

        punteroMatriz->construirEdificio(cleanCoordX, cleanCoordY, nombreEdificio);
    }

    documento.close();*/

    return 0;
}

Archivo::~Archivo()
{
    delete diccionario;
}
