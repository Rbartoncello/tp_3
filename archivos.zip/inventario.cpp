#include <iostream>
#include <fstream>
#include "inventario.h"
#include "constantes.h"

Inventario::Inventario() {
    piedra = 0;
    madera = 0;
    metal = 0;
    bombas = 0;
    andycoins = 0;
}

void Inventario::agregar_material(string nombre, int cantidad){

    if(nombre == PIEDRA)
        piedra = piedra + cantidad;
    else if(nombre == MADERA)
        madera = madera + cantidad;
    else if(nombre == METAL)
        metal = metal + cantidad;
    else if(nombre == BOMBA)
        bombas = bombas + cantidad;
    else if(nombre == ANDYCOINS)
        andycoins = andycoins + cantidad;

}

void Inventario::mostrar() {
    cout<<piedra<<" "<<madera<<" "<<metal<<" "<<bombas<<" "<<andycoins<<endl;
}

Inventario::~Inventario(){

}